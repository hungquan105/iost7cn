//
//  ImageItemCell.swift
//  client
//
//  Created by Quân on 11/23/19.
//  Copyright © 2019 QuanNguyen. All rights reserved.
//

import UIKit

class ImageItemCell: UICollectionViewCell {
    
    @IBOutlet weak var imgv: UIImageView!
}
